
<a href=" https://jeweltheme.com/product/kite-coming-soon-wordpress-plugin/" target="_blank" rel="attachment wp-att-10695"><img class="alignnone wp-image-10695 size-full" src="https://jeweltheme.com/wp-content/uploads/2014/12/MAMA_WP.png" alt="Kite Coming Soon WordPress Plugin " width="615" height="80" /></a><br>

<h1>Kite | Responsive HMTL5 Coming Soon Template</h1>

Kite Coming Soon Template is w3c code validated and carefully designed with attension to the perspective details. This template will attracts visitors very much. Fully featured and contains many features with a minimal outlooks. Customization is never been easier before .

Kite is a modern, minimal, creative fully responsive Under Construction/Coming Soon Template that suits for any creative and business company/agency.

Kite has 4 background variations and 8 color schemes. Parallax effect also added with any kind of devices.
<br/>
<br/>

<h3><a href="http://demos.jeweltheme.com/kite/">See Demo's</a> </h3> <br>

<h2>Features Of Kite Free Responsive Coming Soon HTML5 Template</h2> :
<ol>
<li>8 Color schemes</li>
<li>Fully Responsive</li>
<li>Retina Ready</li>
<li>Cross Browser Support</li>
<li>Built with Bootstrap v3.1.1</li>
<li>W3C validate HTML & CSS</li>
<li>Countdown</li>
<li>Ajax Subscribe and Contact Form(PHP file included for Development)</li>
<li>Well Structured and Commented code</li>
<li>Full screen and Parallax Background</li>
<li>Font Awesome</li>
</ol>

<a href=" https://jeweltheme.com/product/kite-coming-soon-wordpress-plugin/" target="_blank" rel="attachment wp-att-10695"><img class="alignnone wp-image-10695 size-full" src="https://jeweltheme.com/wp-content/uploads/2014/12/MAMA_WP.png" alt="Kite Coming Soon WordPress Plugin " width="615" height="80" /></a><br>

-Designed by <a href="http://themeforest.net/user/bigpsfan">Bigpsfan</a> and Developed by <a href="https://jeweltheme.com">Jewel Theme</a>

